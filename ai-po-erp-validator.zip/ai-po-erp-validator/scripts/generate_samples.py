"""Generate the bundled sample PO PDFs (+ matching mock LLM payloads).

The mock payloads are what Claude returns for each PDF; they let the demo
run offline. Re-run with:  python scripts/generate_samples.py
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pymupdf as fitz

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import config  # noqa: E402

SAMPLES = {
    # 1) Clean order, internal SKUs, correct prices -> APPROVED
    "acme_po_45821": {
        "layout": "classic", "vendor": "Summit Industrial Distribution", "date": "2026-11-03",
        "PO_Number": "45821", "Customer_Name": "Acme Industrial Supply Co.",
        "Ship_To": "1200 Harbor Blvd, Dock 4, Long Beach, CA 90813, USA",
        "Line_Items": [
            {"SKU": "FAS-M8-40-ZN", "Description": "Hex Bolt M8 x 40mm Zinc Plated", "Qty": 20, "UOM": "BX100", "Unit_Price": 18.50},
            {"SKU": "FAS-M8-NUT-ZN", "Description": "Hex Nut M8 Zinc Plated", "Qty": 20, "UOM": "BX100", "Unit_Price": 6.75},
            {"SKU": "PPE-GOG-CLR", "Description": "Safety Goggles Anti-Fog Clear", "Qty": 50, "UOM": "EA", "Unit_Price": 7.95},
        ],
    },
    # 2) Legacy customer SKUs + one description-only line -> APPROVED via mapping/fuzzy
    "initech_po_IN-2026-0917": {
        "layout": "modern", "vendor": "Summit Industrial Distribution", "date": "2026-11-05",
        "PO_Number": "IN-2026-0917", "Customer_Name": "Initech Facilities Group",
        "Ship_To": "300 Corporate Dr, Suite 120, Austin, TX 78741, USA",
        "Line_Items": [
            {"SKU": "PK-300", "Description": "3\" Clear Packing Tape 110 yd", "Qty": 48, "UOM": "RL", "Unit_Price": 3.05},
            {"SKU": "PK-SW18", "Description": "Stretch Film 18in 1500ft", "Qty": 10, "UOM": "RL", "Unit_Price": 21.60},
            {"SKU": None, "Description": "Multifold Paper Towels White 4000 ct", "Qty": 6, "UOM": "CS", "Unit_Price": 38.25},
        ],
    },
    # 3) Price above tolerance (+5.5 %) -> REQUIRES_REVIEW
    "northwind_po_NW-77310": {
        "layout": "modern", "vendor": "Summit Industrial Distribution", "date": "2026-11-06",
        "PO_Number": "NW-77310", "Customer_Name": "Northwind Logistics LLC",
        "Ship_To": "88 Freight Way, Building B, Memphis, TN 38118, USA",
        "Line_Items": [
            {"SKU": "NW-GL-L", "Description": "Nitrile Gloves L Box/100", "Qty": 40, "UOM": "BX", "Unit_Price": 12.40},
            {"SKU": "NW-GL-L-CS", "Description": "Nitrile Gloves L Case/1000", "Qty": 5, "UOM": "CS", "Unit_Price": 115.00},
            {"SKU": "PKG-BOX-1212", "Description": "Corrugated Box 12x12x12", "Qty": 500, "UOM": "EA", "Unit_Price": 1.38},
        ],
    },
    # 4) Scanned image (no text layer), no PO number, ambiguous items -> REQUIRES_REVIEW
    "globex_scan_po": {
        "layout": "scan", "vendor": "Summit Industrial Distribution", "date": "2026-11-07",
        "PO_Number": None, "Customer_Name": "Globex Manufacturing Inc.",
        "Ship_To": "4500 Industrial Pkwy, Columbus, OH 43219, USA",
        "Line_Items": [
            {"SKU": None, "Description": "Hex Bolt M8x40", "Qty": 10, "UOM": "BX", "Unit_Price": 18.50},
            {"SKU": None, "Description": "Ethernet Cable Cat6 1000ft Blue", "Qty": 4, "UOM": "BX", "Unit_Price": 149.00},
            {"SKU": None, "Description": "Gen. Purpose Cleaner 1 Gal", "Qty": 12, "UOM": "EA", "Unit_Price": 14.80},
        ],
    },
    # 5) Customer name that fits two ERP accounts + unexpected ship-to -> REQUIRES_REVIEW
    "acme_services_po_8812": {
        "layout": "classic", "vendor": "Summit Industrial Distribution", "date": "2026-11-08",
        "PO_Number": "AIS-8812", "Customer_Name": "ACME Industrial",
        "Ship_To": "5 Lakeshore Rd, Toronto, ON M5V 2T6, Canada",
        "Line_Items": [
            {"SKU": "PPE-GLV-NIT-M-100", "Description": "Nitrile Gloves Medium Box/100", "Qty": 30, "UOM": "BX", "Unit_Price": 12.40},
            {"SKU": "FAS-WSH-M8", "Description": "Flat Washer M8 Zinc", "Qty": 15, "UOM": "BX100", "Unit_Price": 4.20},
        ],
    },
}


def _money(v: float) -> str:
    return f"${v:,.2f}"


def _draw_classic(page: fitz.Page, s: dict) -> None:
    page.insert_text((50, 60), s["vendor"].upper(), fontsize=10, color=(0.4, 0.4, 0.4))
    page.insert_text((50, 95), "PURCHASE ORDER", fontsize=22, fontname="hebo")
    y = 130
    for label, val in [("P.O. Number:", s["PO_Number"] or ""), ("Date:", s["date"]),
                       ("Buyer:", s["Customer_Name"])]:
        page.insert_text((50, y), label, fontsize=10, fontname="hebo")
        page.insert_text((140, y), val, fontsize=10)
        y += 16
    page.insert_text((50, y + 10), "Ship To:", fontsize=10, fontname="hebo")
    page.insert_textbox(fitz.Rect(140, y, 450, y + 40), s["Ship_To"], fontsize=10)
    y += 60
    cols = [50, 170, 380, 430, 480, 540]
    page.draw_rect(fitz.Rect(45, y - 12, 560, y + 5), color=None, fill=(0.9, 0.9, 0.9))
    for x, h in zip(cols, ["Item #", "Description", "Qty", "UOM", "Price", ""]):
        page.insert_text((x, y), h, fontsize=9, fontname="hebo")
    total = 0.0
    for li in s["Line_Items"]:
        y += 20
        page.insert_text((cols[0], y), li["SKU"] or "", fontsize=9)
        page.insert_text((cols[1], y), li["Description"], fontsize=9)
        page.insert_text((cols[2], y), f"{li['Qty']:g}", fontsize=9)
        page.insert_text((cols[3], y), li["UOM"] or "", fontsize=9)
        page.insert_text((cols[4], y), _money(li["Unit_Price"]), fontsize=9)
        total += li["Qty"] * li["Unit_Price"]
    y += 30
    page.insert_text((400, y), f"TOTAL: {_money(total)}", fontsize=11, fontname="hebo")
    page.insert_text((50, 780), "Please confirm receipt of this order. Net 30.", fontsize=8)


def _draw_modern(page: fitz.Page, s: dict) -> None:
    page.draw_rect(fitz.Rect(0, 0, 612, 70), color=None, fill=(0.12, 0.23, 0.42))
    page.insert_text((40, 45), s["Customer_Name"], fontsize=18, fontname="hebo", color=(1, 1, 1))
    page.insert_text((400, 30), "Order Number", fontsize=8, color=(0.8, 0.85, 1))
    page.insert_text((400, 50), s["PO_Number"] or "", fontsize=14, fontname="hebo", color=(1, 1, 1))
    page.insert_text((40, 100), f"To: {s['vendor']}   |   Issued {s['date']}", fontsize=9)
    page.insert_text((40, 125), "DELIVER TO", fontsize=8, fontname="hebo", color=(0.12, 0.23, 0.42))
    page.insert_text((40, 140), s["Ship_To"], fontsize=10)
    y = 180
    hdr = [(40, "Line"), (75, "Part No."), (160, "Item"), (390, "Qty"), (430, "Unit"), (480, "Unit Cost"), (545, "Ext.")]
    for x, h in hdr:
        page.insert_text((x, y), h, fontsize=8, fontname="hebo", color=(0.12, 0.23, 0.42))
    page.draw_line((40, y + 5), (575, y + 5), color=(0.12, 0.23, 0.42))
    for i, li in enumerate(s["Line_Items"], 1):
        y += 22
        ext = li["Qty"] * li["Unit_Price"]
        for x, v in [(40, str(i)), (75, li["SKU"] or "—"), (160, li["Description"]), (390, f"{li['Qty']:g}"),
                     (430, li["UOM"] or ""), (480, f"{li['Unit_Price']:.2f}"), (530, f"{ext:,.2f}")]:
            page.insert_text((x, y), v, fontsize=9)
    page.insert_text((40, 760), "Authorized by Procurement. Reference all invoices to the Order Number.", fontsize=8)


def _make_pdf(name: str, s: dict, out: Path) -> None:
    doc = fitz.open()
    page = doc.new_page(width=612, height=792)
    (_draw_modern if s["layout"] == "modern" else _draw_classic)(page, s)
    if s["layout"] == "scan":
        # Rasterise and re-embed as an image to simulate a scanned/faxed PO (no text layer)
        pix = page.get_pixmap(dpi=110, colorspace=fitz.csGRAY)
        scan = fitz.open()
        sp = scan.new_page(width=612, height=792)
        sp.insert_image(sp.rect, stream=pix.tobytes("png"), rotate=0)
        scan.save(out)
        scan.close()
    else:
        doc.save(out)
    doc.close()


def main() -> None:
    config.SAMPLE_PDFS_DIR.mkdir(parents=True, exist_ok=True)
    config.MOCK_PAYLOADS_DIR.mkdir(parents=True, exist_ok=True)
    for name, s in SAMPLES.items():
        _make_pdf(name, s, config.SAMPLE_PDFS_DIR / f"{name}.pdf")
        payload = {k: s[k] for k in ("PO_Number", "Customer_Name", "Ship_To", "Line_Items")}
        (config.MOCK_PAYLOADS_DIR / f"{name}.json").write_text(json.dumps(payload, indent=2) + "\n")
        print(f"✓ {name}.pdf + mock payload")


if __name__ == "__main__":
    main()

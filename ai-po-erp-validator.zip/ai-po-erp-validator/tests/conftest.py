import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import config  # noqa: E402
import database  # noqa: E402


@pytest.fixture()
def db(tmp_path, monkeypatch):
    path = tmp_path / "erp.db"
    monkeypatch.setattr(config, "DB_PATH", path)
    monkeypatch.setattr(config, "ERP_IMPORT_DIR", tmp_path / "erp_import")
    database.init_db(reset=True, db_path=path)
    return path

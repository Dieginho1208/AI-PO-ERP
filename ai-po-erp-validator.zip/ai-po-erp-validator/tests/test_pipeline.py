import csv

import pytest

import config
from extractor import DemoPayloadNotFound, POExtractor
from models import FlagCode, LineItem, PurchaseOrder, Status
from pipeline import Pipeline
from validator import POValidator

EXPECTED = {
    "acme_po_45821.pdf": (Status.APPROVED, set()),
    "initech_po_IN-2026-0917.pdf": (Status.APPROVED, set()),
    "northwind_po_NW-77310.pdf": (Status.REQUIRES_REVIEW, {FlagCode.PRICE_MISMATCH}),
    "globex_scan_po.pdf": (Status.REQUIRES_REVIEW, {FlagCode.MISSING_PO_NUMBER, FlagCode.ITEM_AMBIGUOUS}),
    "acme_services_po_8812.pdf": (Status.REQUIRES_REVIEW, {FlagCode.CUSTOMER_AMBIGUOUS, FlagCode.SHIP_TO_MISMATCH}),
}


def _po(**kw):
    base = dict(PO_Number="T-1", Customer_Name="Northwind Logistics LLC",
                Ship_To="88 Freight Way, Building B, Memphis, TN 38118, USA",
                Line_Items=[{"SKU": "PKG-BOX-1212", "Description": "Box", "Qty": 10, "Unit_Price": 1.38}])
    base.update(kw)
    return PurchaseOrder.model_validate(base)


@pytest.mark.parametrize("pdf_name", EXPECTED)
def test_demo_end_to_end(db, pdf_name):
    pipe = Pipeline(extractor=POExtractor(force_demo=True), db_path=db)
    out = pipe.process_pdf(config.SAMPLE_PDFS_DIR / pdf_name)
    status, codes = EXPECTED[pdf_name]
    assert out.result.status == status
    assert {f.code for f in out.result.flags} == codes
    if status == Status.APPROVED:
        rows = list(csv.DictReader(out.csv_path.open()))
        assert len(rows) == len(out.result.lines)
        assert all(r["internal_sku"] for r in rows)
    else:
        assert out.csv_path is None


def test_price_within_tolerance_passes(db):
    v = POValidator(db_path=db)
    ok = v.validate(_po(Line_Items=[{"SKU": "PKG-BOX-1212", "Description": "Box", "Qty": 1, "Unit_Price": 1.39}]))
    bad = v.validate(_po(Line_Items=[{"SKU": "PKG-BOX-1212", "Description": "Box", "Qty": 1, "Unit_Price": 1.40}]))
    assert ok.status == Status.APPROVED            # +0.72 %
    assert bad.flags[0].code == FlagCode.PRICE_MISMATCH  # +1.45 %


def test_normalised_sku_match(db):
    r = POValidator(db_path=db).validate(_po(Line_Items=[
        {"SKU": "fas m8 40 zn", "Description": "bolts", "Qty": 1, "Unit_Price": 18.5}]))
    assert r.lines[0].internal_sku == "FAS-M8-40-ZN"
    assert r.status == Status.APPROVED


def test_unknown_item_flagged(db):
    r = POValidator(db_path=db).validate(_po(Line_Items=[
        {"SKU": None, "Description": "Hydraulic excavator bucket teeth", "Qty": 2, "Unit_Price": 99}]))
    assert {f.code for f in r.flags} & {FlagCode.ITEM_NOT_FOUND, FlagCode.ITEM_AMBIGUOUS}


def test_duplicate_po_detected(db):
    pipe = Pipeline(extractor=POExtractor(force_demo=True), db_path=db)
    pipe.process_pdf(config.SAMPLE_PDFS_DIR / "acme_po_45821.pdf")
    again = pipe.process_pdf(config.SAMPLE_PDFS_DIR / "acme_po_45821.pdf")
    assert FlagCode.DUPLICATE_PO in {f.code for f in again.result.flags}


def test_operator_fix_then_revalidate(db):
    pipe = Pipeline(extractor=POExtractor(force_demo=True), db_path=db)
    out = pipe.process_pdf(config.SAMPLE_PDFS_DIR / "northwind_po_NW-77310.pdf")
    fixed = out.result.order.model_copy(deep=True)
    fixed.line_items[1].unit_price = 109.00
    again = pipe.revalidate(out.order_id, fixed, out.source_file, out.mode)
    assert again.result.status == Status.APPROVED and again.csv_path.exists()


def test_demo_unknown_file_raises():
    with pytest.raises(DemoPayloadNotFound):
        POExtractor(force_demo=True).extract(b"%PDF-1.4", filename="random.pdf")


def test_schema_rejects_bad_payload():
    with pytest.raises(Exception):
        PurchaseOrder.model_validate({"PO_Number": "1", "Customer_Name": "x", "Line_Items": []})
    assert LineItem.model_validate({"SKU": " ", "Description": "d", "Qty": 1, "Unit_Price": 1}).sku is None


def test_live_path_with_stubbed_client(monkeypatch):
    """Exercise the live code path (prompt building, tool parsing, repair retry) without network."""
    from types import SimpleNamespace

    ex = POExtractor(api_key="sk-test", model="claude-sonnet-5-5")
    calls = []
    good = {"PO_Number": "45821", "Customer_Name": "Acme", "Ship_To": None,
            "Line_Items": [{"SKU": "A", "Description": "d", "Qty": 1, "Unit_Price": 2.5}]}
    bad = {"PO_Number": "45821", "Customer_Name": "Acme", "Line_Items": []}

    def fake_call(messages):
        calls.append(messages)
        payload = bad if len(calls) == 1 else good
        block = SimpleNamespace(type="tool_use", id=f"tu_{len(calls)}", input=payload)
        return SimpleNamespace(content=[block], stop_reason="tool_use")

    monkeypatch.setattr(ex, "_call", fake_call)
    out = ex.extract(config.SAMPLE_PDFS_DIR / "acme_po_45821.pdf")
    assert out.mode == "live" and out.order.po_number == "45821"
    assert len(calls) == 2 and "45821" in calls[0][0]["content"][-1]["text"]
    scan_blocks = ex._build_content(__import__("extractor").read_pdf(config.SAMPLE_PDFS_DIR / "globex_scan_po.pdf"), "x.pdf")
    assert scan_blocks[0]["type"] == "image"

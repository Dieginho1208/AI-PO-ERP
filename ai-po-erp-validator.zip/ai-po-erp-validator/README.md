# AI PO → ERP Validator

**Turn messy purchase-order PDFs into clean, ERP-ready import files and let your team review only the exceptions.**

Customers send purchase orders in every format imaginable: branded templates, Excel exports printed to PDF, faxed scans. Someone on your team re-keys each one into the ERP, checks prices against the price list, fixes customer and SKU mismatches, and hopes nothing slips through.

`ai-po-erp-validator` automates that work. A multimodal LLM (Anthropic Claude) reads each PO, a rules engine reconciles it against your ERP master data, and clean orders become import-ready CSV files with no human touch. Only orders with real discrepancies reach the operator, with every problem **highlighted in red** and editable in place.

![Review queue](docs/review_queue.png)

---

## Why it pays for itself

| | Manual process | With AI PO → ERP Validator |
|---|---|---|
| Time per PO | 8–15 min keying + checks | ~10 s extraction, review only on exceptions |
| Price errors caught | Depends on who's on shift | **100 %** checked against the ERP price list (±1 % tolerance) |
| Wrong SKU / look-alike items | Discovered at picking or on the invoice | Flagged before import, with ranked catalog suggestions |
| Duplicate POs | Occasionally double-shipped | Blocked automatically |
| Audit trail | Email threads | Every decision stored with flags, match method and confidence |

**Illustrative ROI** for a distributor receiving 1,500 POs/month:

- 1,500 POs × 12 min = **300 hours/month** of manual entry.
- At a 70 % touchless rate, ~1,050 POs skip the operator entirely: **~210 hours/month recovered** (≈ 1.3 FTE).
- At $30/hour loaded cost, that's **≈ $6,300/month** before counting avoided pricing errors, credit notes and re-shipments.
- LLM cost at that volume is typically a small fraction of that (a few cents per PO, depending on page count and model).

> The dashboard's *Operator time saved* tile calculates this live from your own processed orders.

---

## How it works

```mermaid
flowchart LR
    A[📄 PO PDFs<br/>email · portal · scan] --> B[PyMuPDF<br/>text layer or page images]
    B --> C{{Claude<br/>multimodal extraction}}
    C -->|forced tool call<br/>JSON schema| D[Pydantic<br/>schema validation]
    D --> E[Rules & Reconciliation<br/>rapidfuzz + SQLite ERP]
    E -->|no flags| F[✅ APPROVED]
    E -->|any flag| G[🔴 REQUIRES_REVIEW]
    F --> H[(erp_import/*.csv)]
    G --> I[Operator console<br/>Streamlit]
    I -->|edit + re-validate<br/>or override| E
```

### Reconciliation logic

```mermaid
flowchart TD
    L[PO line item] --> S1{Internal SKU<br/>exact match?}
    S1 -->|yes| P[Price check]
    S1 -->|no| S2{Legacy customer SKU<br/>exact match?}
    S2 -->|yes| P
    S2 -->|no| S3{Normalised SKU<br/>match?}
    S3 -->|yes| P
    S3 -->|no| F[Fuzzy description match<br/>rapidfuzz WRatio]
    F --> C{Confidence ≥ 85 %<br/>and clear winner?}
    C -->|yes| P
    C -->|no| AMB[🚩 ITEM_AMBIGUOUS<br/>+ top-3 suggestions]
    P --> V{"|PO price − ERP price| > 1 %?"}
    V -->|yes| PM[🚩 PRICE_MISMATCH]
    V -->|no| OK[✓ line reconciled]
```

### Processing sequence

```mermaid
sequenceDiagram
    participant Op as Operator
    participant UI as Streamlit console
    participant X as Extractor
    participant LLM as Claude API
    participant V as Validator
    participant DB as ERP (SQLite)
    Op->>UI: Upload PDFs
    UI->>X: process_pdf()
    X->>LLM: system prompt + text/images, tool_choice=record_purchase_order
    LLM-->>X: tool_use JSON
    X->>X: Pydantic validate (auto-repair retry on failure)
    X->>V: PurchaseOrder
    V->>DB: customers, catalog, prior POs
    V-->>UI: ValidationResult (status + flags)
    alt APPROVED
        UI->>UI: write erp_import/PO_<n>.csv
    else REQUIRES_REVIEW
        Op->>UI: fix fields → Re-validate / Approve with override
    end
```

---

## Validation rules

| Flag | Raised when |
|---|---|
| `MISSING_PO_NUMBER` | The document has no PO number |
| `DUPLICATE_PO` | The PO number was already approved and exported |
| `CUSTOMER_NOT_FOUND` / `CUSTOMER_AMBIGUOUS` | Customer name match < 85 %, or two ERP accounts score within 4 points (e.g. *Acme Industrial Supply* vs *Acme Industrial Services*) |
| `SHIP_TO_MISMATCH` | Delivery address differs from the ERP address on file |
| `ITEM_NOT_FOUND` / `ITEM_AMBIGUOUS` | No SKU match and description confidence < 85 %, or two catalog items are near-ties (e.g. zinc vs stainless bolts) |
| `PRICE_MISMATCH` | PO unit price deviates from the ERP price list by more than 1 % |
| `INVALID_QTY` | Quantity ≤ 0 |

All thresholds are configurable through environment variables.

![Flag detail](docs/flags_detail.png)

---

## Key engineering decisions

- **Guaranteed structured output.** Claude is forced to call a single tool whose `input_schema` *is* the Pydantic schema, and the response is validated again with Pydantic. On a schema error, the error is sent back to the model for one self-repair attempt. No regex parsing of free text.
- **Scans and digital PDFs.** PyMuPDF uses the text layer when one exists (cheaper, exact) and falls back to rendering pages as images for scanned or faxed POs, which Claude reads multimodally.
- **Strict, anti-hallucination prompt.** The model extracts only what is printed, returns `null` for missing PO numbers instead of guessing, and never confuses vendor and buyer.
- **Deterministic rules after the AI.** The LLM only reads; every business decision (pricing, matching, approval) is made by transparent, testable Python rules.
- **Demo/Mock mode.** Without an API key, the extractor serves pre-cached payloads for the bundled sample PDFs, so the full workflow can be shown offline at zero cost.
- **Model is configurable.** Defaults to `claude-sonnet-5-5` and can be changed with `ANTHROPIC_MODEL` without touching code.

---

## Quick start

```bash
git clone https://github.com/<you>/ai-po-erp-validator.git
cd ai-po-erp-validator
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

python database.py --reset          # seed the mock ERP
streamlit run app.py                # open http://localhost:8501
```

Click **▶ Run bundled sample POs** in the sidebar. Five sample POs cover the main scenarios:

| Sample | Scenario | Result |
|---|---|---|
| `acme_po_45821.pdf` | Clean PO, internal SKUs | ✅ APPROVED → CSV |
| `initech_po_IN-2026-0917.pdf` | Legacy customer SKUs + description-only line | ✅ APPROVED → CSV |
| `northwind_po_NW-77310.pdf` | Case of gloves priced +5.5 % over list | 🔴 PRICE_MISMATCH |
| `globex_scan_po.pdf` | Scanned image, no PO number, "Hex Bolt M8x40" (zinc or stainless?) | 🔴 MISSING_PO_NUMBER, ITEM_AMBIGUOUS |
| `acme_services_po_8812.pdf` | "ACME Industrial" fits two customers, unknown ship-to | 🔴 CUSTOMER_AMBIGUOUS, SHIP_TO_MISMATCH |

### Live mode (real AI extraction)

```bash
cp .env.example .env
# set ANTHROPIC_API_KEY=sk-ant-...   (optional: ANTHROPIC_MODEL=claude-sonnet-5-5)
streamlit run app.py
```

Any PO PDF can now be uploaded, not just the samples.

### Headless / batch

```bash
python pipeline.py samples/pdfs          # or any folder of PDFs
python extractor.py path/to/po.pdf       # print the extracted JSON
pytest -q                                # 13 tests
```

### ERP import file

One CSV per approved PO in `erp_import/`:

```
po_number,customer_id,customer_name,ship_to,line_no,internal_sku,description,uom,qty,unit_price,line_total,match_method,match_confidence
45821,C-1001,Acme Industrial Supply Co.,"1200 Harbor Blvd, Dock 4, Long Beach, CA 90813, USA",1,FAS-M8-40-ZN,Hex Bolt M8 x 40mm Zinc Plated,BX100,20,18.50,370.00,exact_sku,100.0
```

The column layout lives in `exporter.py` and can be adapted to SAP, NetSuite, Dynamics, Odoo or any other ERP import template.

---

## Project structure

```
ai-po-erp-validator/
├── app.py                 # Streamlit operator console (review queue, approvals, KPIs)
├── pipeline.py            # Orchestration + batch CLI
├── extractor.py           # PyMuPDF + Claude extraction, Demo/Mock mode
├── validator.py           # Rules & fuzzy reconciliation engine
├── exporter.py            # ERP import CSV writer
├── database.py            # Mock ERP (SQLite): customers, catalog, processed orders
├── models.py              # Pydantic contracts (PurchaseOrder, Flag, ValidationResult)
├── config.py              # Env-driven settings
├── scripts/generate_samples.py   # Builds sample PDFs + mock payloads
├── samples/
│   ├── pdfs/              # 5 sample POs (incl. a scanned one)
│   └── mock_payloads/     # Pre-cached LLM output for Demo mode
├── erp_import/            # Generated CSVs land here
├── data/                  # SQLite database (created at runtime)
├── docs/                  # Screenshots
├── tests/                 # pytest suite
├── requirements.txt
└── .env.example
```

---

## Adapting it to a real business

1. **Connect your ERP master data.** Replace the SQLite seed in `database.py` with a read-only view or API pull of your customer and item masters (SAP, NetSuite, Dynamics, Odoo, QuickBooks...).
2. **Map the import format.** Adjust `CSV_COLUMNS` in `exporter.py`, or post directly to the ERP's sales-order API.
3. **Plug in ingestion.** Point an email inbox, SFTP folder or EDI portal at `pipeline.py`.
4. **Tune the rules.** Price tolerance, match thresholds and customer-specific SKU cross-references are configuration, not code.

---

## Tech stack

Python 3.10+ · Anthropic Claude (multimodal, tool use) · PyMuPDF · Pydantic v2 · RapidFuzz · SQLite · Streamlit · pandas · pytest

*Need this wired into your ERP or adapted to your documents (invoices, delivery notes, quotes)? Get in touch.*
